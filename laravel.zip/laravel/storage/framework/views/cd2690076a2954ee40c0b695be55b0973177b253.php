<div class="row">
    <div class="col-lg-12">
        <!-- Recent Order Table -->
        <div class="card card-table-border-none" id="recent-orders">
            <div class="card-header justify-content-between">
                <h2>Recent Orders</h2>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-dismissible fade show alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div>
                    <button class="btn-pill btn btn-primary" id="toggleme" wire:click.prevent='toggleModel'> Add
                        New</button>
                </div>
            </div>
            <div class="pt-0 pb-5 card-body">
                <table class="table card-table table-responsive table-responsive-large" style="width: 100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Category Name</th>
                            <th>Category Slug</th>
                            <th class="d-none d-md-table-cell">Created At</th>
                            <th class="d-none d-md-table-cell">Updated At</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td>
                                    <a class="text-dark" href=""> <?php echo e($item->name); ?></a>
                                </td>
                                <td>
                                    <a class="text-dark" href=""> <?php echo e($item->slug); ?></a>
                                </td>
                                <td class="d-none d-md-table-cell"><?php echo e($item->created_at); ?></td>
                                <td class="d-none d-md-table-cell"><?php echo e($item->updated_at); ?></td>
                                <td class="text-right">
                                    <div class=" dropdown show d-inline-block widget-dropdown">
                                        <a class="dropdown-toggle icon-burger-mini" href="" role="button"
                                            id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false" data-display="static"></a>
                                        <ul class="dropdown-menu dropdown-menu-right"
                                            aria-labelledby="dropdown-recent-order1">
                                            <li class="dropdown-item">
                                                <a href="#"
                                                    wire:click.prevent="editCategory(<?php echo e($item); ?>)">Edit</a>
                                            </li>
                                            <li class="dropdown-item">
                                                <a href="#" wire:click.prevent="deleteCategory(<?php echo e($item->id); ?>)" class="text-danger">Delete</a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-end">
                    <?php echo e($categories->links()); ?>

                </div>
            </div>
        </div>
    </div>
    
    
    <div class="modal fade" id="exampleModalForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle"
        aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if($showEditModel): ?>
                    <h5 class="modal-title" id="exampleModalFormTitle">Edit Category</h5>
                    <?php else: ?>
                    <h5 class="modal-title" id="exampleModalFormTitle">Add Category</h5>
                    <?php endif; ?>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="<?php echo e($showEditModel ? 'updateCategory' : 'addCategory'); ?>">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Category Name</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                            placeholder="Enter Category" wire:model.defer='state.name'>
                            
                            <?php $__errorArgs = ['c_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="alert alert-danger">
                                <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Category Slug</label>
                                <input type="text" class="form-control" id="exampleInputPassword1"
                                placeholder="Enter CategorySlug" wire:model.defer='state.slug'>
                                <?php $__errorArgs = ['c_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="alert alert-danger">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php if($showEditModel): ?>
                        <button type="submit" class="btn btn-primary">Update Category</button>
                        <?php else: ?>
                        <button type="submit" class="btn btn-primary">Add Category</button>
                        <?php endif; ?>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    
    
    <div class="modal fade" id="deleteModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Category</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are You Sure You want to Delete this Category ?
                </div>
                <div class="modal-footer">
            <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary btn-pill" wire:click.prevent='delete'>Delete</button>
        </div>
        </div>
    </div>
</div>
</div><?php /**PATH C:\Users\JONI--HD\Desktop\laravel-livewire-ecommerce\laravel\resources\views/livewire/admin-categories.blade.php ENDPATH**/ ?>