<div>
    
    <div class="col-lg-12">
        <div class="card card-default">
            <div class="card-header justify-content-between">
                <h2>Coupons</h2>
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-dismissible fade show alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                <div>
                    <button class="btn-pill btn btn-primary" id="toggleme" wire:click.prevent='toggleModal'> Add
                        New</button>
                </div>
            </div>
            
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Code</th>                     
                            <th scope="col">Value</th>
                            <th scope="col">Cart Value</th>
                            <th scope="col">Created At</th>
                            <th scope="col">Updated at</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->code); ?></td>
                            <?php if($item->type == 'fixed'): ?>
                            <td>$<?php echo e($item->value); ?></td>
                            <?php else: ?>
                            <td>%<?php echo e($item->value); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($item->cart_value); ?></td> 
                            <td><?php echo e($item->created_at); ?></td> 
                            <td><?php echo e($item->Updated_at); ?></td> 
                            <td class="text-right">
                                <div class=" dropdown show d-inline-block widget-dropdown">
                                    <a class="dropdown-toggle icon-burger-mini" href="" role="button"
                                        id="dropdown-recent-order1" data-toggle="dropdown" aria-haspopup="true"
                                        aria-expanded="false" data-display="static"></a>
                                    <ul class="dropdown-menu dropdown-menu-right"
                                        aria-labelledby="dropdown-recent-order1">
                                        <li class="dropdown-item">
                                            <a href="#"
                                                wire:click.prevent="editCoupon(<?php echo e($item); ?>)">Edit</a>
                                        </li>
                                        <li class="dropdown-item">
                                            <a href="#" wire:click.prevent="deleteCoupon(<?php echo e($item->id); ?>)"
                                                class="text-danger">Delete</a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </tbody>
                </table>
            </div>
        </div>

    </div>


    <div class="modal fade" id="couponModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle" aria-hidden="true" wire:ignore.self>
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if($showEditModel): ?>
                        <h5 class="modal-title" id="exampleModalFormTitle">Edit Coupon</h5>
                    <?php else: ?>
                        <h5 class="modal-title" id="exampleModalFormTitle">Add Coupon</h5>
                    <?php endif; ?>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="<?php echo e($showEditModel ? 'updateCoupon' : 'addCoupon'); ?>">
                        <div class="form-group">
                            <label for="">Coupon Code</label>
                            <input type="text" class="form-control" id="" placeholder="Enter Coupon Code" wire:model.defer='state.code'>
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter Value</label>
                            <input type="number" step="any" class="form-control"  placeholder="Enter Coupon Value" wire:model.defer='state.value'>
                            <?php $__errorArgs = ['value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Enter Cart Value</label>
                            <input type="number" step="any" class="form-control"  placeholder="Enter Coupon Cart Value" wire:model.defer='state.cart_value'>
                            <?php $__errorArgs = ['cart_value'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Select Coupon Type</label>
                            <select name="" id="" wire:model.defer='state.type'>
                                <option value="fixed">Fixed</option>
                                <option value="percent">Percentage</option>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if($showEditModel): ?>
                            <button type="submit" class="btn btn-primary">Update Coupon</button>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary">Add Coupon</button>
                        <?php endif; ?>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Coupon</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Are You Sure You want to Delete this Coupon ?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary btn-pill" wire:click.prevent='delete'>Delete</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\JONI--HD\Desktop\projects...p\laravel-livewire-ecommerce\laravel\resources\views/livewire/admin-coupon.blade.php ENDPATH**/ ?>