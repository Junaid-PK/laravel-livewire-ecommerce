<div>
    <div class="row">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-dismissible fade show alert-success" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <form wire:submit.prevent='updateCategory' class="form form-horizontal">
                <h1>Manage Home Categories</h1>
                <br>
                <br>
                <br>
                <br>
                <div class="form-group">
                    <label for="">Choose Categories</label>
                    <div class="selectbox" wire:ignore>
                        <select name="categories[]" class="sel_category form-control" multiple="multiple" wire:model='selected_category'>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <br>
                <br>
                <div class="form-group">
                    <label for="">No of Products</label>
                    <input type="text" class="col-md-3"  wire:model='noofproducts'>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
        <div class="col-lg-3"></div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.sel_category').select2();
            $('.sel_category').on('change', function(e) {
                var data = $('.sel_category').select2('val');
                window.livewire.find('<?php echo e($_instance->id); ?>').set('selected_category', data);
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\Users\JONI--HD\Desktop\laravel-livewire-ecommerce\laravel\resources\views/livewire/admin-home-category.blade.php ENDPATH**/ ?>