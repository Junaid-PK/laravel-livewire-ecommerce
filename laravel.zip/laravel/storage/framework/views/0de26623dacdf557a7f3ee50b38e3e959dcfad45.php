<div>
    
    <h1>User</h1>
</div>
<?php /**PATH C:\Users\JONI--HD\Desktop\laravel-livewire-ecommerce\laravel\resources\views/livewire/user-dashboard-component.blade.php ENDPATH**/ ?>