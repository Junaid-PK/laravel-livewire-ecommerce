    <div class="modal fade" id="exampleModalForm" tabindex="-1" role="dialog" aria-labelledby="exampleModalFormTitle"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalFormTitle">Add Category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                @if (Session::has('message'))
                    <div class="alert alert-success">{{Session()->get('message')}}</div>
                @endif
            </div>
            <div class="modal-body">
                <form wire:submit.prevent='addCategory'>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Category Name</label>
                        <input type="text" class="form-control" id="exampleInputEmail1"
                            aria-describedby="emailHelp" placeholder="Enter Category" wire:model='c_name' wire:keyup='generateSlug'>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Category Slug</label>
                        <input type="text" class="form-control" id="exampleInputPassword1"
                            placeholder="Enter CategorySlug" wire:model='c_slug'>
                    </div>
                    <div class="pl-0 form-check">
                        <label class="control control-checkbox">Check me out
                            <input type="checkbox" checked="checked" />
                            <div class="control-indicator"></div>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger btn-pill" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary btn-pill">Save Changes</button>
            </div>
        </div>
    </div>
</div>